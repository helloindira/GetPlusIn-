from rest_framework import serializers
from .models import *


class AuthorSerializer(serializers.Serializer):

    class Meta:
        model = Author
        fields =(
            "first_name" 
            "last_name" 
            "address"
            "phone"
            "email"
        )


class ProductSerializer(serializers.Serializer):

    class Meta:
        model = Author
        fields =(
            "title" 
            "pages" 
            "auther" 
            "description" 
            "date" 
            "price" 
        )