from django.shortcuts import render
from rest_framework.views import APIView
from .serializers import *
from rest_framework.response import Response
from rest_framework import viewsets, status
# Create your views here.

class AuthorAPIView(APIView):
    def get(self, request):
        id =self.request.query_params.get('id')
        if id:
            appdata = Author.objects.filter(id=id).values()
            return Response({'result':{'status':'GET by Author id','data':appdata}})
        else:
            appdata = Author.objects.all().values()
            return Response({'result':{'status':'GET ALL','data':appdata}})

    def post(self, request):
        data = request.data
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        address = data.get('address')
        phone = data.get('phone')
        email = data.get('email')
        author_detail=Author.objects.create(first_name=first_name,
                                            last_name = last_name,
                                            address = address,
                                            phone = phone,
                                            email = email)
        return Response(data = author_detail,status= status.HTTP_200_OK)
            
    def put(self, request):
        data = request.data
        id = data.get('id')
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        address = data.get('address')
        phone = data.get('phone')
        email = data.get('email')
        if id:
            data = Author.objects.filter(id=id).update(first_name=first_name,
                                            last_name = last_name,
                                            address = address,
                                            phone = phone,
                                            email = email)
            if data:
                    return Response({'message': 'data Updated Sucessfully.'})
            else:
                response={'message':"Invalid id"}
                return Response(response, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': 'Id Required.'})


    def delete(self, request):
        id=self.request.query_params.get('id')
        category = Author.objects.filter(id=id)
        if len(category) > 0:
            category.delete()
            return Response("data Deleted Sucessfully")
        else:
            return Response("Id Required.",status=status.HTTP_404_NOT_FOUND)

class BookAPIView(APIView):
    def get(self, request):
        id =self.request.query_params.get('id')
        if id:
            appdata = Book.objects.filter(id=id).values()
            return Response({'result':{'status':'GET by Book id','data':appdata}})
        else:
            appdata = Book.objects.all().values()
            return Response({'result':{'status':'GET ALL','data':appdata}})

    def post(self, request):
        data = request.data
        title = data.get('title')
        pages = data.get('pages')
        auther_id = data.get('auther_id')
        date = data.get('date')
        price = data.get('price')
        description = data.get('description')
        auther = Author.objects.get(id =auther_id)
        book_detail=Author.objects.create(title = data.get('title'),
                                        pages = data.get('pages'),
                                        auther = data.get('auther'),
                                        date = data.get('date'),
                                        price = data.get('price'),
                                        description = data.get('description'),
        )
        return Response(data = book_detail,status= status.HTTP_200_OK)
            
    def put(self, request):
        data = request.data
        id = data.get('id')
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        address = data.get('address')
        phone = data.get('phone')
        email = data.get('email')
        if id:
            data = Author.objects.filter(id=id).update(first_name=first_name,
                                            last_name = last_name,
                                            address = address,
                                            phone = phone,
                                            email = email)
            if data:
                    return Response({'message': 'data Updated Sucessfully.'})
            else:
                response={'message':"Invalid id"}
                return Response(response, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': 'Id Required.'})


    def delete(self, request):
        id=self.request.query_params.get('id')
        category = Author.objects.filter(id=id)
        if len(category) > 0:
            category.delete()
            return Response("data Deleted Sucessfully")
        else:
            return Response("Id Required.",status=status.HTTP_404_NOT_FOUND)

