from django.db import models

# Create your models here.



class Author(models.Model):
    first_name = models.CharField(max_length=300)
    last_name = models.CharField(max_length=300)
    address = models.CharField(max_length=300)
    phone = models.CharField(max_length=10)
    email = models.EmailField()

    def __str__(self):
        return self.first_name

      
class Book(models.Model):
    title = models.CharField(max_length=200)
    pages = models.IntegerField()
    auther = models.ForeignKey(Author, on_delete=models.DO_NOTHING, related_name="minor_on_sub_minor")
    description = models.TextField()
    date = models.DateField()
    price = models.DecimalField(max_digits=20, decimal_places=10)


    def __str__(self):
        return self.title
